#!/bin/bash
docker build -t etherproject .

for((i=1;i<=100;i++))
do
  docker run -d --name v$i etherproject
done