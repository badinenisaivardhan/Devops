#!/bin/bash
docker build -t etherproject .

for((i=1;i<=10;i++))
do
  docker run -d --name v_$i etherproject
done