import requests
import socket

currenthost = "Checking Telegram API on : "+ socket.gethostname()
sendmsg = "https://api.telegram.org/bot5441897158:AAEed5PJly3ruG-Lz0VWyIO7C1idhl2Uo1Y/sendMessage?chat_id=-1001516359156&text="+currenthost
response = requests.request("GET", sendmsg)